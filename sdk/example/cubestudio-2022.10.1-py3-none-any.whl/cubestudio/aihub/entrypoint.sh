#!/bin/bash
bash init.sh
exec "$@"



